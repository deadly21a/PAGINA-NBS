module.exports = {
    rules: {
        'bot-whatsapp/func-prefix-goto-flow-return': 2,
        'bot-whatsapp/func-prefix-end-flow-return': 2,
        'bot-whatsapp/func-prefix-dynamic-flow-await': 2,
        'bot-whatsapp/func-prefix-state-update-await': 2,
        'bot-whatsapp/func-prefix-fall-back-return': 2,
    },
}
