# @bot-whatsapp/cli

-   [x] Revisar version de NODE
-   [x] Revisar OS
-   [x] Obtener Package Manager
-   [x] Revisar las libreria de WhatsappWeb para obtener version reciente
-   [x] Opcion interactiva de limpiar session
-   [x] Opcion de generar `json` con la configuracion
-   [x] Agregar `rollup` para limpiar el codigo

---

**Comunidad**

> Forma parte de este proyecto.

-   [Discord](https://link.codigoencasa.com/DISCORD)
-   [Twitter](https://twitter.com/leifermendez)
-   [Youtube](https://www.youtube.com/watch?v=5lEMCeWEJ8o&list=PL_WGMLcL4jzWPhdhcUyhbFU6bC0oJd2BR)
-   [Telegram](https://t.me/leifermendez)
