```
 throw new Error('Evaluation failed: ' + helper_js_1.helper.getExceptionMessage(exceptionDetails));
```

Problema sucede cuando usas la misma sesion luego de reiniciar el bot más de 3 veces lo mejor es seguir los pasos

-   Eliminar **.wwebjs_auth**
