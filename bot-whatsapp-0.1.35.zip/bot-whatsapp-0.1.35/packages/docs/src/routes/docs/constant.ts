export const GITHUB_TOKEN = import.meta.env.VITE_GITHUB_TOKEN ?? 'SIN_TOKEN'
