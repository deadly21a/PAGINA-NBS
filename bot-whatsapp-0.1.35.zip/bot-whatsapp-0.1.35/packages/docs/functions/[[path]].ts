// @ts-ignore

// Cloudflare Pages Functions
// https://developers.cloudflare.com/pages/platform/functions/
export { onRequest } from '../server/entry.cloudflare-pages'
